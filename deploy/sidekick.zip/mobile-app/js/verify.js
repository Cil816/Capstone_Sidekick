const params = new URLSearchParams(window.location.search);
const email = window.SidekickCore.normalizeEmail(params.get("email"));
const emailEl = document.getElementById("verify-email");
const form = document.getElementById("verify-form");
const otpEl = document.getElementById("verify-otp");
const errorEl = document.getElementById("auth-error");
const resendButton = document.getElementById("resend-otp");

emailEl.textContent = email || "your email";

function showMessage(message) {
  errorEl.textContent = message;
  errorEl.removeAttribute("hidden");
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  errorEl.setAttribute("hidden", "hidden");
  const otp = otpEl.value.trim();
  if (!email || !/^\d{6}$/.test(otp)) {
    showMessage("Invalid or expired code. Please try again.");
    return;
  }

  const button = form.querySelector("button[type=submit]");
  button.disabled = true;
  window.SidekickUI?.loading.show();
  try {
    const result = await window.SidekickCore.apiRequest("/api/verify-otp", {
      method: "POST",
      body: JSON.stringify({ email, otp }),
    });
    window.SidekickCore.setAuthSession({
      email: result.user.email,
      name: result.user.name,
      apiToken: result.session?.token || "",
      loggedInAt: Date.now(),
    });
    // Verifying completes a brand-new account: start onboarding fresh for this email.
    window.SidekickCore.recordAccountForEmail(result.user.email, result.user.user_id, { newAccount: true });
    const destination = window.SidekickCore.getPreferences() ? "dashboard.html" : "onboarding.html";
    // Keep the loading screen up while the next page opens.
    window.SidekickUI?.loading.show();
    window.location.href = destination;
  } catch (error) {
    window.SidekickUI?.loading.hide(true);
    showMessage(window.SidekickCore.friendlyError(error, "Invalid or expired code. Please try again."));
  } finally {
    window.SidekickUI?.loading.hide();
    button.disabled = false;
  }
});

resendButton.addEventListener("click", async () => {
  errorEl.setAttribute("hidden", "hidden");
  resendButton.disabled = true;
  try {
    await window.SidekickCore.apiRequest("/api/resend-otp", {
      method: "POST",
      body: JSON.stringify({ email }),
    });
    showMessage("A new verification code has been sent.");
  } catch (error) {
    showMessage(window.SidekickCore.friendlyError(error, "Unable to resend the code. Please try again."));
  } finally {
    resendButton.disabled = false;
  }
});
